package com.profile_management.controller;

import com.profile_management.model.Company;
import com.profile_management.service.CompanyProfileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
@CrossOrigin
@RestController
@RequestMapping("/api/company")
public class CompanyController {

    @Autowired
    private CompanyProfileService companyProfileService;

    // Create or Update company profile
    @PutMapping("/{companyId}")
    public ResponseEntity<?> updateCompanyProfile(
            @PathVariable Long companyId,
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String industry,
            @RequestParam(required = false) MultipartFile profileImage
    ) {
        try {
            Company updatedCompany = companyProfileService.updateCompanyProfile(companyId, name, industry, profileImage);
            return ResponseEntity.ok(updatedCompany);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    // Get company profile
    @GetMapping("/{companyId}")
    public ResponseEntity<?> getCompanyProfile(@PathVariable Long companyId) {
        try {
            Company company = companyProfileService.getCompanyProfile(companyId);
            return ResponseEntity.ok(company);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Company not found");
        }
    }
}
