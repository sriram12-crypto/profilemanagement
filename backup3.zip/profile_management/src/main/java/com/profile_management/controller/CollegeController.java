package com.profile_management.controller;

import com.profile_management.model.College;
import com.profile_management.service.CollegeProfileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@CrossOrigin
@RestController
@RequestMapping("/api/college")
public class CollegeController {

    @Autowired
    private CollegeProfileService collegeProfileService;

    // Create or Update college profile
    @PutMapping("/{collegeId}")
    public ResponseEntity<?> updateCollegeProfile(
            @PathVariable Long collegeId,
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String address,
            @RequestParam(required = false) MultipartFile profileImage
    ) {
        try {
            College updatedCollege = collegeProfileService.updateCollegeProfile(collegeId, name, address, profileImage);
            return ResponseEntity.ok(updatedCollege);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    // Get college profile
    @GetMapping("/{collegeId}")
    public ResponseEntity<?> getCollegeProfile(@PathVariable Long collegeId) {
        try {
            College college = collegeProfileService.getCollegeProfile(collegeId);
            return ResponseEntity.ok(college);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("College not found");
        }
    }
}

