package com.profile_management.controller;


import com.profile_management.model.*;
import com.profile_management.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
@CrossOrigin
@RestController
@RequestMapping("/api/student")
public class StudentController {

    @Autowired
    private StudentProfileService studentProfileService;

    // Create or Update student profile
    @PutMapping("/{studentId}")
    public ResponseEntity<?> updateStudentProfile(
            @PathVariable Long studentId,
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String phone,
            @RequestParam(required = false) String enrollmentNumber,
            @RequestParam(required = false) String course,
            @RequestParam(required = false) MultipartFile profileImage
    ) {
        try {
            Student updatedStudent = studentProfileService.updateStudentProfile(studentId, name, phone, enrollmentNumber, course, profileImage);
            return ResponseEntity.ok(updatedStudent);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    // Get student profile
    @GetMapping("/{studentId}")
    public ResponseEntity<?> getStudentProfile(@PathVariable Long studentId) {
        try {
            Student student = studentProfileService.getStudentProfile(studentId);
            return ResponseEntity.ok(student);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Student not found");
        }
    }
}
