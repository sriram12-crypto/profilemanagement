package com.profile_management.controller;

import com.profile_management.model.User;
import com.profile_management.service.UserProfileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api/profile")
public class UserProfileController {

    @Autowired
    private UserProfileService userProfileService;

    // Create a new user profile
    @PostMapping("/adddetails")
    public ResponseEntity<User> createProfile(
            @RequestParam String email,
            @RequestParam String name,
            @RequestParam String phone,
            @RequestParam MultipartFile profileImage
    ) {
        try {
            User createdUser = userProfileService.createProfile(email, name, phone, profileImage);
            return new ResponseEntity<>(createdUser, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }
    }

    // Read user profile by ID
    @GetMapping("/{userId}")
    public ResponseEntity<User> getProfile(@PathVariable Long userId) {
        try {
            User user = userProfileService.getProfile(userId);
            return ResponseEntity.ok(user);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }

    // Get all user profiles
    @GetMapping("/")
    public ResponseEntity<List<User>> getAllProfiles() {
        try {
            List<User> users = userProfileService.getAllProfiles();
            return ResponseEntity.ok(users);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    // Update user profile by ID
    @PutMapping("/{userId}")
    public ResponseEntity<?> updateProfile(
            @PathVariable Long userId,
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String phone,
            @RequestParam(required = false) MultipartFile profileImage
    ) {
        try {
            User updatedUser = userProfileService.updateProfile(userId, name, phone, profileImage);
            return ResponseEntity.ok(updatedUser);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    // Delete user profile by ID
    @DeleteMapping("/{userId}")
    public ResponseEntity<String> deleteProfile(@PathVariable Long userId) {
        try {
            userProfileService.deleteProfile(userId);
            return ResponseEntity.ok("User profile deleted successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
        }
    }
}
