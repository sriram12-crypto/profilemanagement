package com.profile_management.controller;



import com.profile_management.service.UserDetailsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private UserDetailsServiceImpl userDetailsService;

    @Autowired
    private AuthenticationManager authenticationManager;

    // Login endpoint to authenticate the user and create a session
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestParam String email, @RequestParam String password) {
        try {
            // Authenticate the user
            UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(email, password);
            authenticationManager.authenticate(authenticationToken);

            // If authentication is successful, Spring Security automatically creates a session
            SecurityContextHolder.getContext().setAuthentication(authenticationToken);

            return ResponseEntity.ok("Login successful");
        } catch (Exception e) {
            return ResponseEntity.status(401).body("Invalid credentials");
        }
    }

    // Logout endpoint to invalidate the session
    @PostMapping("/logout")
    public ResponseEntity<?> logout() {
        // Invalidates the session by clearing the security context
        SecurityContextHolder.clearContext();
        
        return ResponseEntity.ok("Logged out successfully");
    }
}
