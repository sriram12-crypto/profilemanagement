package com.profile_management.model;

import jakarta.persistence.Entity;

@Entity
public class Student extends User {
    
    private String enrollmentNumber;
    private String course;

    // Getters and Setters
    public String getEnrollmentNumber() {
        return enrollmentNumber;
    }

    public void setEnrollmentNumber(String enrollmentNumber) {
        this.enrollmentNumber = enrollmentNumber;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }
}
