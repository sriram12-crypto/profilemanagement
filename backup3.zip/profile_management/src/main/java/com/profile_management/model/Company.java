package com.profile_management.model;

import jakarta.persistence.Entity;

@Entity
public class Company extends User {

    private String companyName;
    private String industry;

    // Getters and Setters
    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getIndustry() {
        return industry;
    }

    public void setIndustry(String industry) {
        this.industry = industry;
    }
}
