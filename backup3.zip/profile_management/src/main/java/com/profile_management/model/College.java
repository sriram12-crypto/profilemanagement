package com.profile_management.model;

import jakarta.persistence.Entity;

@Entity
public class College extends User {

    private String collegeName;
    private String address;

    // Getters and Setters
    public String getCollegeName() {
        return collegeName;
    }

    public void setCollegeName(String collegeName) {
        this.collegeName = collegeName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

	public void setLogoUrl(String logoUrl) {
		// TODO Auto-generated method stub
		
	}
}
