package com.profile_management.security;

import com.profile_management.service.UserDetailsServiceImpl;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(); // Password encoder bean
    }

    @Bean
    public UserDetailsServiceImpl userDetailsService() {
        return new UserDetailsServiceImpl(); // Custom user details service for authentication
    }

    @Bean
    public AuthenticationManager authenticationManager(HttpSecurity http) throws Exception {
        AuthenticationManagerBuilder authenticationManagerBuilder = 
                http.getSharedObject(AuthenticationManagerBuilder.class);
        authenticationManagerBuilder.userDetailsService(userDetailsService()).passwordEncoder(passwordEncoder());
        return authenticationManagerBuilder.build();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf().disable() // Disabling CSRF for simplicity, enable it based on your needs.
            .authorizeRequests()
                .requestMatchers(HttpMethod.POST, "/api/student/**").hasRole("ADMIN")  // Allow POST to student profile only for admins
                .requestMatchers(HttpMethod.PUT, "/api/student/**").hasRole("ADMIN")   // Allow PUT to student profile only for admins
                .requestMatchers(HttpMethod.GET, "/api/student/**").hasAnyRole("ADMIN", "USER")  // Both admin and user can GET
                .requestMatchers(HttpMethod.POST, "/api/college/**").hasRole("ADMIN") // POST requests for college profile by ADMIN
                .requestMatchers(HttpMethod.PUT, "/api/college/**").hasRole("ADMIN")  // PUT requests for college profile by ADMIN
                .requestMatchers(HttpMethod.GET, "/api/college/**").hasAnyRole("ADMIN", "USER")  // GET requests allowed for ADMIN and USER
                .requestMatchers(HttpMethod.POST, "/api/company/**").hasRole("ADMIN") // POST requests for company profile by ADMIN
                .requestMatchers(HttpMethod.PUT, "/api/company/**").hasRole("ADMIN") // PUT requests for company profile by ADMIN
                .requestMatchers(HttpMethod.GET, "/api/company/**").hasAnyRole("ADMIN", "USER")  // GET requests allowed for ADMIN and USER
                .anyRequest().authenticated() // All other requests require authentication
            .and()
                .formLogin().permitAll()  // Enable form login
            .and()
                .httpBasic().disable();  // Disable basic authentication for better security, can be enabled for certain cases if needed

        return http.build();
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(userDetailsService());
        authProvider.setPasswordEncoder(passwordEncoder());
        return authProvider;
    }
}
