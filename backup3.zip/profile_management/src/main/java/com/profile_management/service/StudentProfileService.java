package com.profile_management.service;



import com.profile_management.model.Student;
import com.profile_management.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Optional;

@Service
public class StudentProfileService {

    @Autowired
    private StudentRepository studentRepository;

    public Student updateStudentProfile(Long studentId, String name, String phone, String enrollmentNumber, String course, MultipartFile profileImage) throws IOException {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));

        if (name != null) student.setName(name);
        if (phone != null) student.setPhone(phone);
        if (enrollmentNumber != null) student.setEnrollmentNumber(enrollmentNumber);
        if (course != null) student.setCourse(course);
        if (profileImage != null) student.setProfileImage(profileImage.getBytes());

        return studentRepository.save(student);
    }

    public Student getStudentProfile(Long studentId) {
        return studentRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));
    }
}
