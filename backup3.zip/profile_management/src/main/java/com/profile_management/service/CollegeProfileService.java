package com.profile_management.service;


import com.profile_management.model.College;
import com.profile_management.repository.CollegeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Service
public class CollegeProfileService {

    @Autowired
    private CollegeRepository collegeRepository;

    public College updateCollegeProfile(Long collegeId, String name, String address, MultipartFile profileImage) throws IOException {
        College college = collegeRepository.findById(collegeId)
                .orElseThrow(() -> new RuntimeException("College not found"));

        if (name != null) college.setCollegeName(name);
        if (address != null) college.setAddress(address);
        if (profileImage != null) college.setProfileImage(profileImage.getBytes());

        return collegeRepository.save(college);
    }

    public College getCollegeProfile(Long collegeId) {
        return collegeRepository.findById(collegeId)
                .orElseThrow(() -> new RuntimeException("College not found"));
    }
}
