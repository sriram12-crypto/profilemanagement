package com.profile_management.service;

import com.profile_management.model.Student;
import com.profile_management.model.User;
import com.profile_management.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Service
public class UserProfileService {

    @Autowired
    private UserRepository userRepository;

    // Create a new user profile
    public Student createProfile(String email, String name, String phone, MultipartFile profileImage) throws IOException {
        Student newStudent = new Student();  // Instantiate Student instead of User
        newStudent.setEmail(email);
        newStudent.setName(name);
        newStudent.setPhone(phone);
        newStudent.setProfileImage(profileImage.getBytes());
        return userRepository.save(newStudent);
    }
    // Get user profile by ID
    public User getProfile(Long userId) throws Exception {
        Optional<User> userOptional = userRepository.findById(userId);
        if (userOptional.isPresent()) {
            return userOptional.get();
        } else {
            throw new Exception("User not found with ID: " + userId);
        }
    }

    // Get all user profiles
    public List<User> getAllProfiles() {
        return userRepository.findAll();
    }

    // Update user profile by ID
    public User updateProfile(Long userId, String name, String phone, MultipartFile profileImage) throws Exception {
        Optional<User> userOptional = userRepository.findById(userId);
        if (userOptional.isPresent()) {
            User existingUser = userOptional.get();
            if (name != null) existingUser.setName(name);
            if (phone != null) existingUser.setPhone(phone);
            if (profileImage != null) existingUser.setProfileImage(profileImage.getBytes());
            return userRepository.save(existingUser);
        } else {
            throw new Exception("User not found with ID: " + userId);
        }
    }

    // Delete user profile by ID
    public void deleteProfile(Long userId) throws Exception {
        Optional<User> userOptional = userRepository.findById(userId);
        if (userOptional.isPresent()) {
            userRepository.delete(userOptional.get());
        } else {
            throw new Exception("User not found with ID: " + userId);
        }
    }
}
