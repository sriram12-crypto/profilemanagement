package com.profile_management.service;


import com.profile_management.model.Company;
import com.profile_management.repository.CompanyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Service
public class CompanyProfileService {

    @Autowired
    private CompanyRepository companyRepository;

    public Company updateCompanyProfile(Long companyId, String name, String industry, MultipartFile profileImage) throws IOException {
        Company company = companyRepository.findById(companyId)
                .orElseThrow(() -> new RuntimeException("Company not found"));

        if (name != null) company.setCompanyName(name);
        if (industry != null) company.setIndustry(industry);
        if (profileImage != null) company.setProfileImage(profileImage.getBytes());

        return companyRepository.save(company);
    }

    public Company getCompanyProfile(Long companyId) {
        return companyRepository.findById(companyId)
                .orElseThrow(() -> new RuntimeException("Company not found"));
    }
}
