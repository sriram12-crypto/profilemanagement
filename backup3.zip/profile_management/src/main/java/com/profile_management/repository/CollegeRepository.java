package com.profile_management.repository;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.profile_management.model.College;

@Repository
public interface CollegeRepository extends JpaRepository<College, Long> {
}
