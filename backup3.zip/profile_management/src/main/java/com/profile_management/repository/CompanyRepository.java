package com.profile_management.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.profile_management.model.Company;

public interface CompanyRepository extends JpaRepository<Company, Long> {
}
